---
name: nextags-prompt-fixer
description: "Audit and fix customer-service AI prompts for the NexTags Messenger Messaging Platform. Use to review, validate, lint, audit or correct a NexTags-style prompt (uploaded as `.md` or pasted). Triggers PT ('corrigir prompt', 'validar prompt', 'auditar prompt', 'revisar prompt do bot', 'JSON do prompt quebrado') and EN ('fix nextags prompt', 'lint bot prompt'). Catches/repairs invalid JSON, transfer actions (recommends `send_flow` as default; `transfer_conversation_to`/`assign_conversation` stay valid as fallback), `web_url` buttons without `url`, carousels with under 2 items, standard-markdown leaking into JSON text fields (WhatsApp `*bold*`/`_italic_`/`~strike~` is allowed), missing sections, and canonical handoff fields (blocks the AI writing `setor_agente`/`tipo_setor`; enforces `motivo_transferencia`/`prioridade_pipeline`/`resumo_pipeline` before `send_flow`). Preserves persona, flows, knowledge base and business rules. Outputs corrected `.md` + Portuguese report."
---

# NexTags Prompt Fixer

Audita e corrige prompts de agentes de atendimento da plataforma NexTags
contra as **Regras Absolutas** da Messenger Messaging Platform.

## O que essa skill faz

Recebe um prompt (`.md` ou texto colado) e devolve:

1. Uma **versão corrigida** do prompt (`.md`).
2. Um **relatório em Markdown** descrevendo cada mudança e cada pendência.

A skill **só toca em violações estruturais**. Ela jamais altera persona,
fluxos, base de conhecimento, IDs de fluxos, URLs, tom de voz ou qualquer
regra de negócio. Quando uma correção exige decisão de produto que só o
humano dono do projeto pode tomar (ex.: "qual é o ID do fluxo de
transferência?"), a skill **deixa um placeholder marcado** e lista no
relatório como pendência.

**Relação com a `nextags-json-fixer`.** As duas tratam
`transfer_conversation_to`/`assign_conversation`/`unassign_conversation`
como **válidas** — nenhuma as proíbe. A json-fixer valida o JSON que a
plataforma ACEITA em runtime; esta skill cuida do prompt e apenas **recomenda
`send_flow` como padrão** (porque 100% das transferências de qualidade nos 25
prompts de produção usam `send_flow`). Mas `transfer_conversation_to` é
fallback legítimo quando não há fluxo de transferência, e `assign_conversation`
é caso especial raro (atendente específico). São camadas complementares, sem
conflito. Ver Regra 2 em `regras_absolutas.md`.

**Relação com `references/campos_canonicos.md`.** É a fonte de verdade única
do método (compartilhada com `nextags-prompt-creator`, `nextags-mcp-builder`
e `nextags-webhook-builder`) para quem escreve cada campo, o enum de
`motivo_transferencia`, os critérios de `prioridade_pipeline`/`resumo_pipeline`
e a arquitetura de Roteador/Revalidador. Esta skill audita CONTRA esse
documento — `regras_absolutas.md` (Regras 21-23) e `cufs_nextags.md` trazem só
o resumo operacional de auditoria; o detalhe (tabelas, critérios, exemplos,
legado) vive em `campos_canonicos.md`.

**Exceção Roteador/Revalidador.** Um prompt que só classifica em UMA PALAVRA
(`setor_agente` ou `tipo_setor`) não é um "agente" no sentido das regras
acima — não produz JSON, não transfere, não tem AVISOS ATIVOS. Ver Regra 23.

## Quando essa skill se aplica

Use sempre que o usuário mencionar:

- Um prompt de agente NexTags / Messenger Messaging Platform.
- Erros em prompts de atendimento, bots, chatbots para WhatsApp/Messenger.
- "Corrigir / validar / auditar / revisar / lintar" um prompt.
- JSON quebrado em exemplos de resposta.
- Suspeita de uso indevido de botões, carrosséis ou ações da plataforma.

## Fluxo de trabalho

### 1. Captura o input

O input pode chegar de duas formas:

- **Arquivo `.md` enviado** → caminho em `/mnt/user-data/uploads/<nome>.md`.
- **Texto colado no chat** → salve em `/home/claude/input_prompt.md` antes
  de prosseguir.

Se o input for ambíguo (ex.: o usuário descreveu um problema mas não enviou
o prompt), peça o conteúdo antes de continuar.

### 2. Roda a análise

A skill traz um analisador determinístico em Python que detecta todos os
problemas de uma vez. Use-o sempre — não tente reinventar a auditoria
"no olho".

```bash
# Substitua <SKILL_DIR> pelo diretório desta skill (onde este SKILL.md vive).
python <SKILL_DIR>/scripts/analyze_prompt.py \
    <caminho_do_prompt.md> \
    --mode fixer \
    --output /tmp/findings.json
```

O script produz um JSON estruturado com:

- `summary` — contadores agregados.
- `json_blocks` — cada bloco JSON do prompt, marcado como válido/inválido,
  com a lista de violações encontradas e se é um exemplo negativo
  intencional (esses são preservados, não contam como erro).
- `forbidden_actions_in_prose` — menções a ações proibidas no texto fora
  dos blocos JSON.
- `missing_sections` — seções de instrução obrigatórias ausentes.
- `json_only_instruction_present` — booleano: o prompt instrui o agente a
  responder somente em JSON?

Leia o `findings.json` antes de propor correções.

### 3. Aplica correções com critério

**Sempre consulte `references/regras_absolutas.md` antes de corrigir** —
ele descreve o padrão de fix para cada tipo de violação, com exemplos antes
e depois.

Princípios:

- **Preserve a função, corrija só a forma.** Se uma correção mudaria o
  comportamento do agente (não só a estrutura do JSON), vira pendência.
- **Não invente valores.** Se faltar um `flow_id`, uma URL, ou texto que
  não está no prompt, deixe placeholder explícito (ex.:
  `<ID_DO_FLUXO_PIPELINE>`) e liste no relatório.
- **Exemplos negativos são intocáveis.** Quando o autor mostra um JSON
  precedido de "❌ ERRADO" ou "🚫 NUNCA", esse bloco é didático. O analisador
  já marca esses como `is_negative_example: true` — não corrija.
- **Idempotência.** Rodar a skill duas vezes seguidas sobre o mesmo prompt
  no segundo run deve produzir zero correções (porque a primeira já
  resolveu tudo que dava pra resolver).
- **Idioma do prompt = idioma do output.** Se o prompt está em PT-BR, o
  arquivo corrigido continua em PT-BR. Relatório sempre em PT-BR (foi o
  combinado com o usuário).

Tabela rápida de correções (detalhes em `references/regras_absolutas.md`):

| Violação | Estratégia |
|---|---|
| JSON inválido | Reescreva com sintaxe válida, mantendo intenção. Se ambíguo → pendência. |
| `transfer_conversation_to` / `assign_conversation` | NÃO são proibidas. `send_flow` é o padrão recomendado; `transfer_conversation_to` é fallback válido quando não há fluxo de transferência, `assign_conversation` é caso especial raro (atendente específico). Só sugerir `send_flow` quando houver fluxo disponível. Ver Regra 2. |
| Botão `web_url` sem `url` | Pendência (precisa da URL) ou converter em texto. `postback` é válido (dispara fluxo) — preservar. Ver Regra 3. |
| Carrossel com 1 item | Quebrar em mensagem de texto + attachment de imagem. |
| Markdown em `text`/`subtitle` | WA-markup (`*negrito*`, `_itálico_`, `~tachado~`) RENDERIZA e é OK — não tocar. Remover só markdown-PADRÃO que vaza (`**duplo**`, `# título`, `[texto](url)`, bullets `-`, cercas ```` ``` ````). Ver Regra 5. |
| **`send_flow` sem `messages`** (regra #10) | NÃO é erro. `send_flow` DISPARA NORMALMENTE — o fluxo assume a comunicação. `messages` é transição OPCIONAL por UX, nunca obrigatória. Preservar disparo silencioso; só sugerir transição se agregar à experiência. |
| **Exemplos JSON em fence `` ```json ``** (regra #11) | Remover os fences dos exemplos. LLM em runtime copia o padrão e quebra a plataforma. |
| Menção em prosa a `transfer_conversation_to`/`assign_conversation` | Não é violação por si só (ação válida). Se houver fluxo de transferência, SUGERIR `send_flow`; senão, deixar. Ver Regra 6. |
| Seção obrigatória faltando | Inserir placeholder com bloco-padrão sugerido (não inventar regras de negócio) + listar como pendência. |
| Bloco oficial ausente OU variante (prompt que usa JSON) | Verificar se o prompt produz JSON; se sim, inserir o bloco canônico LITERAL. Se já houver uma variante de formato, NORMALIZAR para o canônico SEM duplicar (uma instrução de formato só; regras do projeto vêm depois). Ver Regra 12. |
| **Agente tem tools/MCP mas falta a cláusula "function call ≠ saída JSON"** | Inserir a cláusula logo após o bloco oficial. Sem ela, o "só JSON" faz o modelo achar que não pode emitir function call → para de chamar as tools (finge/qualifica em loop/fabrica dado). Ver Regra 10 em `regras_absolutas.md` (caso Veuske 2026-06-11, log da OpenAI). |
| **Seção proibida no prompt** (Auditoria, Changelog, Pendências, TODO, Notas internas, metadata expandido `**Versão:**`, `**Data:**`) | **Remover INTEIRA do prompt**. Migrar o conteúdo pro relatório (seção "Histórico de mudanças", "Pendências para revisão humana" ou "Notas técnicas/TODO"). Ver Regra 15 em `regras_absolutas.md`. |
| Função de transferência inventada/legada (`connect_user_to_human`, `transferir_suporte`, `Rotativo()`) | Converter pra `send_flow` + placeholder de `flow_id`; funções de DADO viram pendência (tool/MCP). Ver Regra 2b. |
| `send_flow` SÓ-actions (NPS/descadastro/mockup/etc.) | **NÃO corrigir** — disparo silencioso é o comportamento normal de `send_flow` (Regra 10). O fluxo fala. |
| `assign_conversation` com `admin_id` = nome ("Estela.") | `admin_id` inválido → pendência (precisa do ID real) ou `send_flow` se o intuito era roteamento genérico; nunca adivinhar o ID. A ação em si não é proibida. Ver Regra 2. |
| Ordem `send_flow` antes de `set_field_value` | Reordenar: campos PRIMEIRO, `send_flow` por último (senão campos chegam vazios). Ver Regra 16. |
| `>1` botão `web_url` / CTA >20 chars / botão de carrinho pra produto | Ver Regra 17. `postback` é PERMITIDO (até 3, raro); 1 só botão `web_url` por mensagem (limite WhatsApp). |
| Data fixa que apodrece ("28/02", "até hoje") / preço literal em exemplo com tool | Ver Regra 18 (datas e preço literal). |
| `{{first_name}}` vazio/"Guest"/não-nome (TODOS os canais) | Saudação neutra + perguntar o nome UMA vez + `set_field_value first_name`. Nunca saudar por `{{ig_user_name}}`/`{{page_user_name}}`/username (identificador, não vocativo; vetor de injeção). Ver Regra 14 (itens 5-6). |
| Regra de disparo/broadcast ausente em agente com campanhas ativas | Sugerir adicionar à Anti-alucinação. Ver Regra 20. |
| Empurrar pra outro número / reapresentar após handoff | Sugerir (não bloquear): usar `send_flow` no mesmo canal; não repetir saudação inicial pós-handoff. Ver Regra 20b. |
| `avisos_ativos_presente` = ausente | Inserir bloco `📣 AVISOS ATIVOS` vazio no formato canônico (correção estrutural). Ver Regra 22. |
| `nota_editor_longa` | Encurtar a linha `> 🔧 NOTA PARA EDITORES:` para ≤200 caracteres, preservando a intenção. Ver Regra 22. |
| `ia_grava_campo_de_roteamento` (**block**) | `set_field_value` em `setor_agente`/`tipo_setor` num JSON de agente: remover a action; se a intenção era "trocar de IA", converter em transferência para humano (trio + `send_flow`) e registrar pendência. Ver Regra 21. |
| `motivo_fora_do_enum` | Valor de `motivo_transferencia` fora do enum canônico (§2.1): mapear se for legado conhecido (`duvidas`→`duvida`, `sac_geral`→`duvida`, etc.); se for enum próprio documentado no prompt, registrar como aviso resolvido. Ver Regra 21. |
| `prioridade_pipeline` fora de `baixa\|media\|alta` (**block**) | Corrigir para o valor mais próximo do enum ou `baixa` (default) — Seleção única rejeita qualquer outro valor. Ver Regra 21. |
| `trio_handoff_incompleto` | `send_flow` de transferência sem os 3 `set_field_value` (motivo/prioridade/resumo) antes: inserir os que faltam. Ver Regra 21 (campo stale). |
| `send_flow_antes_de_set_field` | Reordenar: `set_field_value`(s) sempre antes do `send_flow` no mesmo array. Ver Regra 16. |

### 4. Versionamento do arquivo corrigido

Use o esquema do meta-prompt do usuário:

- Se o nome original era `prompt-atendimento-v1.0.md` → corrigida
  `prompt-atendimento-v1.1.md` (correções estruturais leves).
- Se não havia versionamento no nome → adicione `-corrigido` no nome.

Salve em `/mnt/user-data/outputs/`.

### 5. Gera o relatório

Use `assets/relatorio_template.md` como base e preencha os placeholders.
Salve em `/mnt/user-data/outputs/relatorio-<nome>.md`.

O relatório precisa, no mínimo:

- Resumir quantas correções foram feitas e quantas pendências sobraram.
- Listar cada correção com **antes/depois** e justificativa em uma frase.
- Listar cada pendência com **localização**, **o que falta**, e
  **sugestão** do que fazer.
- Trazer a tabela de estatísticas (vem direto do `summary` do findings).
- Confirmar explicitamente que persona, fluxos, base de conhecimento e
  regras de negócio foram preservados.

### 6. Apresenta os arquivos

Use `present_files` com o `.md` corrigido **primeiro** e o relatório em
seguida. Na resposta, escreva uma síntese curta (3–5 linhas) do que mudou
no nível mais alto, citando os números do summary. Não repita o relatório
no chat — o arquivo já cobre.

## Edge cases que merecem atenção

**Prompt parcial / fragmento.** Se o usuário enviou só uma parte (ex.: só
um bloco JSON), corrija o que foi enviado, mas avise no relatório que a
auditoria não cobre as seções obrigatórias (porque não há prompt inteiro).

**Meta-prompt em vez de agent prompt.** Às vezes o usuário envia o
**meta-prompt** (o que gera prompts de agente) em vez do prompt do agente
em si. Esses arquivos *contêm intencionalmente* exemplos negativos e
discussões sobre as regras — o analisador tenta detectar via marcadores
(`❌`, `🚫`, "proibido"), mas pode haver falsos positivos. Se o conteúdo
parecer ser um meta-prompt (ex.: tem seções como "Modo Auditor", "Hierarquia
de Verdade", "Inputs Obrigatórios"), pergunte ao usuário se ele quer mesmo
corrigir esse arquivo ou se enviou o errado.

**Conflito entre violações.** Quando duas violações apontam para correções
opostas (ex.: tem botão sem URL dentro de um carrossel com 1 item só), não
tente resolver as duas ao mesmo tempo — vira pendência composta com
descrição clara das opções.

**Diff muito grande.** Se o número de correções passar de ~15, alerte o
usuário no resumo: o prompt provavelmente precisa ser refeito do zero, não
remendado.

**Prompt de Roteador ou Revalidador (saída de 1 palavra).** Não aplique as
regras de agente (bloco oficial JSON, `send_flow`/trio de handoff, AVISOS
ATIVOS, seções obrigatórias de agente) — esses prompts não conversam com o
cliente nem produzem JSON. Ver Regra 23 em `references/regras_absolutas.md`
para o que auditar de fato nesse caso.

**Prompt inchado (>30 KB).** Sempre meça `wc -c` no início e reporte no
relatório. Prompts NexTags ideais ficam em 15-20 KB. Acima de 30 KB,
**sugira redução** com base nas estratégias da Regra 13
(`references/regras_absolutas.md`): remover changelog/histórico de versões,
remover pendências internas, consolidar fluxos similares (Troca/Devolução/
Defeito/Cancelamento), converter prosa em tabela, cortar exemplos negativos
redundantes, cortar regras duplicadas. Acima de 45 KB, recomendar reescrita
do zero. NÃO faça redução automática sem confirmação humana — alta chance
de cortar algo que o dono considera essencial.

## Estrutura desta skill

```
nextags-prompt-fixer/
├── SKILL.md                              (este arquivo)
├── scripts/
│   └── analyze_prompt.py                 análise determinística (cópia idêntica: creator/fixer)
├── references/
│   ├── regras_absolutas.md               regras + padrões de fix
│   ├── campos_canonicos.md               fonte de verdade do método (cópia idêntica em 4 skills — não editar aqui)
│   └── cufs_nextags.md                   CUFs nativos da plataforma (cópia idêntica: creator/fixer)
└── assets/
    └── relatorio_template.md             template do relatório
```
