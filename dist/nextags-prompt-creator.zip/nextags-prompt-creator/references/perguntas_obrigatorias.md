# Checklist de Perguntas Obrigatórias

> Antes de gerar o prompt, valide TODAS as perguntas abaixo com o humano. Cada
> uma é uma decisão de produto que **só o humano pode tomar**. Se ficar sem
> resposta, **mantenha como pendência explícita** no prompt final (placeholder
> `<...>`) e liste no relatório — **nunca chute** o valor.

---

## Como conduzir as perguntas

**Princípio: perguntar BASTANTE.** Questionário completo antes de gerar, mesmo que
dê mais rodadas — menos suposição. O **TIPO** do agente é inferido do briefing/site
e confirmado rápido (1 pergunta); o **resto** é perguntado a fundo. O custo de chutar
(refazer o prompt) é maior que o de uma rodada a mais. Só não pergunte o que o
site/briefing já cobrem (ver "O que NÃO perguntar").

Use `ask_user_input_v0` para perguntas de múltipla escolha (mais ergonômico
para mobile). Use prosa para as abertas (IDs, URLs, listas). **Agrupe em até
3 perguntas por chamada do tool** — esse é o limite. Se precisar de mais,
faça uma segunda rodada após a primeira ser respondida.

Sugestão de divisão por rodadas:

- **Rodada 1 — Persona e tom:** tom de voz, público-alvo, canais.
- **Rodada 2 — Tools e fluxos:** uso de MCP, `flow_id` do pipeline + enum de
  `motivo_transferencia`, fluxos que o cliente já tem para delegar.
- **Rodada 3 — Operação e conteúdo:** horário de atendimento + SLA, CUFs que a IA
  deve ler, mídias, restrições comerciais, tratamento de reclamações.

Pule rodadas cujas respostas já estejam no briefing.

---

## 1. Persona e voz

### 1.1 Nome do agente
Exemplo de pergunta: "Como o agente vai se chamar?"
Tipo: aberta.

### 1.2 Tom de voz
Pergunta multipla-escolha:
```
options: ["Formal e corporativo", "Informal e próximo", "Consultivo/técnico",
          "Energético/motivacional", "Acolhedor/empático", "Outro (descrever)"]
```

### 1.3 Público-alvo
Pergunta aberta: "Quem é o cliente típico? (idade aproximada, perfil, dor
que está resolvendo)"

### 1.4 Canais de atendimento
```
type: multi_select
options: ["WhatsApp", "Instagram Direct", "Facebook Messenger",
          "Site/webchat", "TikTok"]
```

---

## 1.0 Tipo de agente (PERGUNTA-CHAVE — define quais seções gerar)
```
options: ["Vendas/consultora", "SAC/pós-venda", "Triagem/roteador",
          "Comercial/SDR (B2B)", "Misto (vendas + SAC)"]
```

## 1.5 Perguntas condicionais por tipo

**Se VENDAS:** frase de abertura assinatura? produto-hero a priorizar? há cupom —
e em que momento mencionar? lead de anúncio entra direto no produto ou diagnóstico?
há léxico de marca (palavras preferidas / a evitar / PROIBIDAS — ex.: nunca dizer "defeito")?
Há **caso de sucesso, depoimento ou dado autorizado** pra usar como prova social
(cliente, contexto, resultado)? E alguma **credencial real** (tempo de mercado,
certificação) pra usar como autoridade? Sem resposta aqui, o agente NÃO pode citar
prova social/autoridade — ver `references/metodologia_vendas_consultivas.md` §5.

**Se SAC:** quais MOTIVOS de contato atende? O padrão canônico do SAC é
`rastreio` / `devolucao` / `troca` / `duvida` (catch-all) — confirme se serve ou se
falta algum. Qual a tool/sistema que é fonte de verdade de ENVIO (≠ e-commerce)?
Há fluxo de NPS pós-atendimento (`flow_id`)?

**Se COMERCIAL/SDR:** quais campos do CRM capturar via `set_field_value` além do
trio de handoff (pipeline, faturamento, origem)? Horário de expediente?

**Todos:** respostas fixas para casos sensíveis (atacado, parceria, vagas)?
A saída para humano é sempre disponível — confirme que não existe regra de "só
transfere em horário comercial" (se existir, o agente escala mesmo assim e o fluxo
avisa o horário; nunca empurra o cliente para outro número).

---

## 2. Tools e fluxos

### 2.1 O agente vai usar tools (MCP)?
```
options: ["Sim — vou listar quais", "Não usa tools",
          "Não sei ainda (pendência)"]
```

Se "Sim", pergunta aberta: "Liste as tools disponíveis e o que cada uma faz
(nome + 1-2 linhas descrevendo input/output)."

### 2.2 ID do fluxo de PIPELINE (UM só, para todo handoff humano)
Pergunta aberta: "Qual o `flow_id` do fluxo de **pipeline** (transferência para
humano)? É um só — a fila é decidida pelo CUF `motivo_transferencia`, que o próprio
fluxo filtra."

Pergunte também, na mesma rodada:

1. "O fluxo filtra os valores canônicos por setor — parcerias
   (`ugc` / `colaboracao` / `influencer` / `revenda` / `atacado`), comercial
   (`vendas` / `carrinho`) e SAC (`rastreio` / `devolucao` / `troca` / `duvida`,
   com `else` caindo no SAC) — ou vocês usam outros valores?"
2. "O fluxo lê `prioridade_pipeline` (`baixa` / `media` / `alta`) para definir a
   prioridade do card? E `resumo_pipeline` vai para o comentário/descrição do card?"
3. "Tem algum **setor extra** com IA própria (ex.: uma IA de Parcerias)? Se sim, o
   roteador ganha essa palavra e o fluxo de entrada ganha o ramo."
4. "Precisa de algum valor **extra** no enum (ex.: `garantia` num painel de SAC
   próprio)? Por padrão `garantia` cai em `duvida`" (evidência: Cantarola usa
   `garantia` no pipeline de varejo — Demanda ClickUp Cantarola).

⚠️ **Não peça um flow_id por motivo.** O padrão canônico é UM fluxo de pipeline;
pedir vários gera prompt com N placeholders e depois exige refatoração (caso real:
Joias Degan, 66 ocorrências de 3 placeholders trocadas depois). Ver
`references/campos_canonicos.md` §2.

⚠️ Se o humano não souber o id agora: **mantenha `<ID_DO_FLUXO_PIPELINE>`** e liste
como pendência crítica. Se ele não souber os valores do enum, use os canônicos —
errar um valor degrada para o `else` (fila de SAC), não perde o cliente.

⚠️ Valide o id antes de escrever no prompt: `GET /accounts/flows`. A NexTags
retorna `success:true` em `/send/{flow_id}` até para id inexistente (evidência:
Alto Giro) — id errado falha em silêncio.

### 2.2b Horário de atendimento humano e SLA
Pergunta aberta: "Qual o **horário do atendimento humano**? (vira o CUF
`horario_atendimento`, que o fluxo de pipeline interpola nas mensagens de espera —
ex.: 'Segunda a sexta-feira, das 8h às 18h'.) E qual o **SLA** para o time responder
um card novo? O padrão do fluxo é `data_vencimento` = agora + 2h."

⚠️ Sem essa resposta, use o padrão (2h) e registre no relatório. O texto do horário
é do cliente — não invente.

### 2.2c Quais CUFs da conta a IA deve LER
Pergunta aberta: "Quais campos personalizados da conta a IA precisa **ler** para
decidir? A IA só enxerga o campo se ele estiver escrito no prompt como `{{campo}}` —
campo preenchido no contato sem a tag no prompt é invisível para ela."

Exemplos canônicos para sugerir (só inclua o que a conta realmente tem):

| Situação | Campos a ler |
|---|---|
| Todo agente | `{{first_name}}`, `{{phone}}`, `{{email}}`, `{{current_user_time}}` |
| SAC com transacional | `{{numero_pedido}}`, `{{status_pedido}}`, `{{rastreio_codigo}}`, `{{rastreio_url}}`, `{{previsao_entrega}}`, `{{origem_pedido}}` |
| Carrinho abandonado | `{{produtos_carrinho}}`, `{{valor_carrinho}}`, `{{link_carrinho}}` |
| Espera / fila | `{{horario_atendimento}}` |

⚠️ Não inclua campo "por precaução": cada `{{campo}}` extra entra no contexto em
TODO turno, inclusive vazio ou com valor velho (stale). Ver `cufs_nextags.md`.

### 2.3 Outros fluxos específicos?
Pergunta aberta: "Há outros fluxos da NexTags que o agente deve disparar
em situações pontuais? (ex.: fluxo de carrinho abandonado com ID `flow_xxx`,
fluxo de avaliação pós-atendimento, etc.) Liste cada um."

⚠️ Mesma regra: sem ID confirmado → placeholder + pendência.

### 2.4 Quais fluxos NexTags o cliente JÁ TEM (pra a IA delegar)?
Pergunta aberta: "Quais fluxos de bot vocês já têm montados na NexTags que a IA
pode acionar? Especialmente os que renderizam coisa pesada ou estruturada —
catálogo grande / vários carrosséis, PDF/documento, ou coleta complexa (medidas,
formulário). Liste cada um (propósito + `flow_id`)."

⚠️ A IA **delega ao fluxo** o que é pesado/estruturado em vez de montar payload
gigante (ver "DELEGUE AO FLUXO" no skeleton). A fronteira IA↔fluxo é dirigida
pelos fluxos que o cliente já tem. Sem `flow_id` confirmado → placeholder + pendência.

---

## 3. Conteúdo e regras

### 3.1 Restrições comerciais
Pergunta aberta: "Há regras comerciais ou restrições absolutas? Ex.: 'não
oferecer desconto fora de PIX', 'nunca prometer cura', 'não comparar com
concorrentes', etc. Liste tudo."

### 3.2 Tratamento de reclamações
```
options: ["Tentar resolver com autonomia até 2 tentativas, depois transferir",
          "Sempre transferir reclamações para humano",
          "Resolver com autonomia, transferir só Procon/processo",
          "Outro (descrever)"]
```

### 3.3 Mídias disponíveis
Pergunta aberta: "Há imagens, áudios ou vídeos para o agente usar nas
respostas? Liste cada URL e em que situação usar (ou diga que vem das tools
dinamicamente, ou que não tem)."

⚠️ Sem URLs → o prompt **não** pode prometer envio de mídia (caia em texto
simples).

---

## 4. Verificação final antes de gerar

Antes de chamar `analyze_prompt.py`, confirme com o humano:

- ✅ Briefing entendido
- ✅ Site escaneado (homepage + páginas-chave)
- ✅ Inconsistências entre briefing e site reportadas
- ✅ Todas as 3 rodadas de perguntas respondidas (ou marcadas como pendência)
- ✅ `flow_id` do fluxo de PIPELINE fornecido e validado em `GET /accounts/flows`
  (ou `<ID_DO_FLUXO_PIPELINE>` explicitamente marcado como pendência crítica)
- ✅ Enum de `motivo_transferencia` confirmado (canônico ou com as exceções do
  cliente registradas)
- ✅ Lista dos `{{campos}}` que a IA vai LER definida (bloco DADOS DESTA CONVERSA)
- ✅ Horário de atendimento humano e SLA capturados (ou padrão 2h registrado)

Só então prossiga para a geração + auditoria.

---

## O que NÃO perguntar

Não desperdice rodada com coisas que o briefing/site já cobrem:

- Endereço, contatos, horário → vem do site
- Catálogo de produtos → vem do site (e/ou tools)
- Políticas (troca, garantia, frete) → vem do site
- Diferenciais da marca → vem do site
- "Quem somos" → vem do site

Se algo dessas coisas não estiver no site E não estiver no briefing, **aí sim**
pergunte — mas só nesse caso.
